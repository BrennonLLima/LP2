﻿namespace PClasses
{
    partial class frm_Mensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnsim = new System.Windows.Forms.RadioButton();
            this.rbtnnao = new System.Windows.Forms.RadioButton();
            this.txtboxdata = new System.Windows.Forms.TextBox();
            this.txtboxsalario = new System.Windows.Forms.TextBox();
            this.txtboxnome = new System.Windows.Forms.TextBox();
            this.txtboxmatricula = new System.Windows.Forms.TextBox();
            this.btninstanciar1 = new System.Windows.Forms.Button();
            this.lbldata = new System.Windows.Forms.Label();
            this.lblsalario = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblmatricula = new System.Windows.Forms.Label();
            this.btninstanciar2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnsim);
            this.groupBox1.Controls.Add(this.rbtnnao);
            this.groupBox1.Location = new System.Drawing.Point(525, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 123);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trabalha em HomeOffice?";
            // 
            // rbtnsim
            // 
            this.rbtnsim.AutoSize = true;
            this.rbtnsim.Checked = true;
            this.rbtnsim.Location = new System.Drawing.Point(15, 33);
            this.rbtnsim.Name = "rbtnsim";
            this.rbtnsim.Size = new System.Drawing.Size(42, 17);
            this.rbtnsim.TabIndex = 22;
            this.rbtnsim.TabStop = true;
            this.rbtnsim.Text = "Sim";
            this.rbtnsim.UseVisualStyleBackColor = true;
            // 
            // rbtnnao
            // 
            this.rbtnnao.AutoSize = true;
            this.rbtnnao.Location = new System.Drawing.Point(15, 71);
            this.rbtnnao.Name = "rbtnnao";
            this.rbtnnao.Size = new System.Drawing.Size(45, 17);
            this.rbtnnao.TabIndex = 23;
            this.rbtnnao.TabStop = true;
            this.rbtnnao.Text = "Não";
            this.rbtnnao.UseVisualStyleBackColor = true;
            // 
            // txtboxdata
            // 
            this.txtboxdata.Location = new System.Drawing.Point(179, 139);
            this.txtboxdata.Name = "txtboxdata";
            this.txtboxdata.Size = new System.Drawing.Size(100, 20);
            this.txtboxdata.TabIndex = 20;
            // 
            // txtboxsalario
            // 
            this.txtboxsalario.Location = new System.Drawing.Point(179, 109);
            this.txtboxsalario.Name = "txtboxsalario";
            this.txtboxsalario.Size = new System.Drawing.Size(100, 20);
            this.txtboxsalario.TabIndex = 19;
            // 
            // txtboxnome
            // 
            this.txtboxnome.Location = new System.Drawing.Point(179, 83);
            this.txtboxnome.Name = "txtboxnome";
            this.txtboxnome.Size = new System.Drawing.Size(100, 20);
            this.txtboxnome.TabIndex = 18;
            // 
            // txtboxmatricula
            // 
            this.txtboxmatricula.Location = new System.Drawing.Point(179, 55);
            this.txtboxmatricula.Name = "txtboxmatricula";
            this.txtboxmatricula.Size = new System.Drawing.Size(100, 20);
            this.txtboxmatricula.TabIndex = 17;
            // 
            // btninstanciar1
            // 
            this.btninstanciar1.Location = new System.Drawing.Point(124, 298);
            this.btninstanciar1.Name = "btninstanciar1";
            this.btninstanciar1.Size = new System.Drawing.Size(215, 75);
            this.btninstanciar1.TabIndex = 15;
            this.btninstanciar1.Text = "Instanciar Mensalista";
            this.btninstanciar1.UseVisualStyleBackColor = true;
            this.btninstanciar1.Click += new System.EventHandler(this.Btninstanciar1_Click);
            // 
            // lbldata
            // 
            this.lbldata.AutoSize = true;
            this.lbldata.Location = new System.Drawing.Point(44, 139);
            this.lbldata.Name = "lbldata";
            this.lbldata.Size = new System.Drawing.Size(129, 13);
            this.lbldata.TabIndex = 14;
            this.lbldata.Text = "Data Entrada na Empresa";
            // 
            // lblsalario
            // 
            this.lblsalario.AutoSize = true;
            this.lblsalario.Location = new System.Drawing.Point(44, 111);
            this.lblsalario.Name = "lblsalario";
            this.lblsalario.Size = new System.Drawing.Size(39, 13);
            this.lblsalario.TabIndex = 13;
            this.lblsalario.Text = "Salário";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(44, 83);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 12;
            this.lblnome.Text = "Nome";
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Location = new System.Drawing.Point(44, 55);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(50, 13);
            this.lblmatricula.TabIndex = 11;
            this.lblmatricula.Text = "Matricula";
            // 
            // btninstanciar2
            // 
            this.btninstanciar2.Location = new System.Drawing.Point(447, 298);
            this.btninstanciar2.Name = "btninstanciar2";
            this.btninstanciar2.Size = new System.Drawing.Size(215, 75);
            this.btninstanciar2.TabIndex = 16;
            this.btninstanciar2.Text = "Instanciar Mensalista passando parâmetros";
            this.btninstanciar2.UseVisualStyleBackColor = true;
            this.btninstanciar2.Click += new System.EventHandler(this.Btninstanciar2_Click);
            // 
            // frm_Mensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtboxdata);
            this.Controls.Add(this.txtboxsalario);
            this.Controls.Add(this.txtboxnome);
            this.Controls.Add(this.txtboxmatricula);
            this.Controls.Add(this.btninstanciar2);
            this.Controls.Add(this.btninstanciar1);
            this.Controls.Add(this.lbldata);
            this.Controls.Add(this.lblsalario);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.lblmatricula);
            this.Name = "frm_Mensalista";
            this.Text = "frm_Mensalista";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtboxdata;
        private System.Windows.Forms.TextBox txtboxsalario;
        private System.Windows.Forms.TextBox txtboxnome;
        private System.Windows.Forms.TextBox txtboxmatricula;
        private System.Windows.Forms.Button btninstanciar1;
        private System.Windows.Forms.Label lbldata;
        private System.Windows.Forms.Label lblsalario;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.RadioButton rbtnsim;
        private System.Windows.Forms.RadioButton rbtnnao;
        private System.Windows.Forms.Button btninstanciar2;
    }
}