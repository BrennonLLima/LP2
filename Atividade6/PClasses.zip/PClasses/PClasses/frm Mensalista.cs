﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frm_Mensalista : Form
    {
        public frm_Mensalista()
        {
            InitializeComponent();
        }

        private void Btninstanciar1_Click(object sender, EventArgs e)
        {
            // criar ou instanciar o objeto da classe mensalista

            Mensalista objMensalista = new Mensalista();

            //set
            objMensalista.Matricula = Convert.ToInt32(txtboxmatricula.Text);
            objMensalista.NomeEmpregado = txtboxnome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtboxdata.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtboxsalario.Text);

            if (rbtnsim.Checked)
                objMensalista.HomeOffice = 'S';
            else
                objMensalista.HomeOffice = 'N';

            //get
            MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" +
                "Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Data Entrada: " +
                objMensalista.DataEntradaEmpresa.ToShortDateString() +
                "\n" +
                "Salario Bruto: " + objMensalista.SalarioBruto().ToString("N2") +
                "\n" +
                "Tempo Empresa (dias): " + objMensalista.TempoTrabalho() +
                "\n" + objMensalista.VerificaHome());



        }

        private void Btninstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtboxmatricula.Text),
                txtboxnome.Text,
                Convert.ToDateTime(txtboxdata.Text),
                Convert.ToDouble(txtboxsalario.Text));


            if (rbtnsim.Checked)
                objMensalista.HomeOffice = 'S';
            else
                objMensalista.HomeOffice = 'N';


            MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" +
                "Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Data Entrada: " +
                objMensalista.DataEntradaEmpresa.ToShortDateString() +
                "\n" +
                "Salario Bruto: " + objMensalista.SalarioBruto().ToString("N2") +
                "\n" +
                "Tempo Empresa (dias): " + objMensalista.TempoTrabalho() +
                "\n" + objMensalista.VerificaHome());


        }
    }
}
