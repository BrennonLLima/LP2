﻿namespace PClasses
{
    partial class frm_Horista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblsalario = new System.Windows.Forms.Label();
            this.lbldata = new System.Windows.Forms.Label();
            this.btninstanciar1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnsim = new System.Windows.Forms.RadioButton();
            this.rbtnnao = new System.Windows.Forms.RadioButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Location = new System.Drawing.Point(53, 49);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(50, 13);
            this.lblmatricula.TabIndex = 0;
            this.lblmatricula.Text = "Matricula";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(53, 77);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "Nome";
            // 
            // lblsalario
            // 
            this.lblsalario.AutoSize = true;
            this.lblsalario.Location = new System.Drawing.Point(53, 106);
            this.lblsalario.Name = "lblsalario";
            this.lblsalario.Size = new System.Drawing.Size(83, 13);
            this.lblsalario.TabIndex = 2;
            this.lblsalario.Text = "Salário por Hora";
            // 
            // lbldata
            // 
            this.lbldata.AutoSize = true;
            this.lbldata.Location = new System.Drawing.Point(53, 156);
            this.lbldata.Name = "lbldata";
            this.lbldata.Size = new System.Drawing.Size(129, 13);
            this.lbldata.TabIndex = 3;
            this.lbldata.Text = "Data Entrada na Empresa";
            // 
            // btninstanciar1
            // 
            this.btninstanciar1.Location = new System.Drawing.Point(297, 272);
            this.btninstanciar1.Name = "btninstanciar1";
            this.btninstanciar1.Size = new System.Drawing.Size(215, 75);
            this.btninstanciar1.TabIndex = 4;
            this.btninstanciar1.Text = "Instanciar Horista";
            this.btninstanciar1.UseVisualStyleBackColor = true;
            this.btninstanciar1.Click += new System.EventHandler(this.Btninstanciar1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(188, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(188, 77);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(188, 103);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(188, 153);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnsim);
            this.groupBox1.Controls.Add(this.rbtnnao);
            this.groupBox1.Location = new System.Drawing.Point(527, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 123);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Trabalha em HomeOffice?";
            // 
            // rbtnsim
            // 
            this.rbtnsim.AutoSize = true;
            this.rbtnsim.Checked = true;
            this.rbtnsim.Location = new System.Drawing.Point(18, 34);
            this.rbtnsim.Name = "rbtnsim";
            this.rbtnsim.Size = new System.Drawing.Size(42, 17);
            this.rbtnsim.TabIndex = 24;
            this.rbtnsim.TabStop = true;
            this.rbtnsim.Text = "Sim";
            this.rbtnsim.UseVisualStyleBackColor = true;
            // 
            // rbtnnao
            // 
            this.rbtnnao.AutoSize = true;
            this.rbtnnao.Location = new System.Drawing.Point(18, 72);
            this.rbtnnao.Name = "rbtnnao";
            this.rbtnnao.Size = new System.Drawing.Size(45, 17);
            this.rbtnnao.TabIndex = 25;
            this.rbtnnao.TabStop = true;
            this.rbtnnao.Text = "Não";
            this.rbtnnao.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(188, 179);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Dias de falta";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(188, 127);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Número Horas";
            // 
            // frm_Horista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btninstanciar1);
            this.Controls.Add(this.lbldata);
            this.Controls.Add(this.lblsalario);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.lblmatricula);
            this.Name = "frm_Horista";
            this.Text = "frm_Horista";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblsalario;
        private System.Windows.Forms.Label lbldata;
        private System.Windows.Forms.Button btninstanciar1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnsim;
        private System.Windows.Forms.RadioButton rbtnnao;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label2;
    }
}