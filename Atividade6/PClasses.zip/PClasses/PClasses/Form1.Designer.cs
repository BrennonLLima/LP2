﻿namespace PClasses
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmensal = new System.Windows.Forms.Button();
            this.btnhorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnmensal
            // 
            this.btnmensal.Font = new System.Drawing.Font("Minion Pro", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmensal.Location = new System.Drawing.Point(185, 168);
            this.btnmensal.Name = "btnmensal";
            this.btnmensal.Size = new System.Drawing.Size(191, 76);
            this.btnmensal.TabIndex = 0;
            this.btnmensal.Text = "Mensalista";
            this.btnmensal.UseVisualStyleBackColor = true;
            this.btnmensal.Click += new System.EventHandler(this.Btnmensal_Click);
            // 
            // btnhorista
            // 
            this.btnhorista.Font = new System.Drawing.Font("Minion Pro", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhorista.Location = new System.Drawing.Point(428, 168);
            this.btnhorista.Name = "btnhorista";
            this.btnhorista.Size = new System.Drawing.Size(191, 76);
            this.btnhorista.TabIndex = 1;
            this.btnhorista.Text = "Horista";
            this.btnhorista.UseVisualStyleBackColor = true;
            this.btnhorista.Click += new System.EventHandler(this.Btnhorista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnhorista);
            this.Controls.Add(this.btnmensal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnmensal;
        private System.Windows.Forms.Button btnhorista;
    }
}

