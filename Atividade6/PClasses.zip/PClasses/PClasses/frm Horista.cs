﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frm_Horista : Form
    {
        public frm_Horista()
        {
            InitializeComponent();
        }

        private void Btninstanciar1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.Matricula = Convert.ToInt32(textBox1.Text);
            objHorista.NomeEmpregado = textBox2.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(textBox4.Text);
            objHorista.SalarioHora = Convert.ToDouble(textBox3.Text);
            objHorista.NumeroHora = Convert.ToDouble(textBox6.Text);
            objHorista.DiasFalta = Convert.ToInt32(textBox5.Text);
            if (rbtnsim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';

            MessageBox.Show("Matricula: " + objHorista.Matricula + "\n" +
                 "Nome: " + objHorista.NomeEmpregado + "\n" +
               "Data Entrada: " +
                  objHorista.DataEntradaEmpresa.ToShortDateString() +
                  "\n" +
                  "Salario Bruto: " + objHorista.SalarioBruto().ToString("N2") +
                  "\n" +
                  "Tempo Empresa (dias): " + objHorista.TempoTrabalho() +
                 "\n" + objHorista.VerificaHome());




        }
    }
}
