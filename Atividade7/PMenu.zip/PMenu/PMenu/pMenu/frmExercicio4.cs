﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (int i = 0; i < rchtxtFrase.TextLength; i++)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                    contador++;
            }
            MessageBox.Show("Existem "+contador.ToString("N0")+" Numeros");
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int i = 0;
            while (i < rchtxtFrase.TextLength)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    break;
                }
                else
                {
                    contador++;
                    i++;
                }

            }
            contador += 1;
            MessageBox.Show("A primeiro espaço em branco está na posição: " + contador.ToString("N0"));
        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char i in rchtxtFrase.Text)
            {
                if (char.IsLetter(i))
                {
                    contador++;
                }
            }
            MessageBox.Show("A quantidade de letras no texto é: " + contador.ToString("N0"));
        }
    }
}
