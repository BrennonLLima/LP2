﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemov_Click(object sender, EventArgs e)
        {
            int posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);

            if (posicao >= 0)
            {
            int tamanho = txtPalavra1.Text.Length;

            string parte1 = txtPalavra2.Text.Substring(0, posicao);
            string parte2 = txtPalavra2.Text.Substring(posicao + tamanho);

                string resultado = parte1 + parte2;

                MessageBox.Show(resultado);
            }

            else
                MessageBox.Show(txtPalavra2.Text+"\nNão há ocorrencias.");
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
           string replace = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
            MessageBox.Show(replace);
        }

        private void btnInverte_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray();

            Array.Reverse(vetor);

            string retorno = "";

            foreach (char c in vetor)
            {
                retorno += c;
            }
            MessageBox.Show(retorno);
        }
    }
}
