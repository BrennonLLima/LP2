﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso Inválido");
                txtPeso.Focus();
            }
            else if (peso <= 0)
            {
                MessageBox.Show("O Peso deve ser maior que zero.");
                txtPeso.Focus();
            }
            else if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                txtAltura.Focus();
            }
            else if (altura <= 0)
            {
                MessageBox.Show("A Altura deve ser maior que zero.");
                txtAltura.Focus();
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);

                imc = Math.Round(imc, 1);

                if (imc < 18.5)
                    MessageBox.Show("Seu IMC é: " + imc.ToString("N2") + "  Classificação: Magreza");
                else if (imc <= 24.9)
                    MessageBox.Show("Seu IMC é: " + imc.ToString("N2") + "  Classificação: Normal");
                else if (imc <= 29.9)
                    MessageBox.Show("Seu IMC é: " + imc.ToString("N2") + "  Classificação: Sobrepeso");
                else if (imc <= 39.9)
                    MessageBox.Show("Seu IMC é: " + imc.ToString("N2") + "  Classificação: Obesidade");
                else
                    MessageBox.Show("Seu IMC é: " + imc.ToString("N2") + "  Classificação: Obesidade Grave");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
        }

        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (e.KeyChar == (char)(13))
                {
                    SendKeys.Send("{TAB}");
                    e.Handled = true;
                }
            }
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (e.KeyChar == (char)(13))
                {
                    SendKeys.Send("{TAB}");
                    e.Handled = true;
                }
            }
        }
    }
}
