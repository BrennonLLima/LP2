﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482221034
{
    public partial class FrmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();

        public FrmContato()
        {
            InitializeComponent();

        }

        private void FrmContato_Load(object sender, EventArgs e)    
        {
            try
            {
                Contato Cont = new Contato();
            dsContato.Tables.Add(Cont.Listar());
            bnContato.DataSource = dsContato.Tables["Contato"];
            dgvContato.DataSource = bnContato;
            bnvContato.BindingSource = bnContato;

            txtIDContato.DataBindings.Add("TEXT", bnContato, "id_contato");
            txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_contato");
            txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
            txtTelefone.DataBindings.Add("TEXT", bnContato, "cel_contato");
            txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
            dtpDtCadastro.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];
                //CAMPO QUE SERÁ MOSTRADO PARA O USUÁRIO
                cbxCidade.DisplayMember = "nome_cidade";
                //CAMPO QUE É A CHAVE DA TABELA CIDADE E QUE LIGA
                //COM A TABELA DE ALUNO
                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch(Exception)
            {
                MessageBox.Show("Erro ao listar contatos!");
            }
        }

        private void BtnIncluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }

            bnContato.AddNew();
            
            txtIDContato.Enabled = false;
            txtNomeContato.Enabled = true;
            txtEndereco.Enabled = true;
            cbxCidade.Enabled = true;
            txtTelefone.Enabled = true;
            dtpDtCadastro.Enabled = true;
            txtEmail.Enabled = true;

            cbxCidade.SelectedIndex = 0;

            btnIncluir.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {

            if (txtNomeContato.Text == "" || txtNomeContato.Text.Length < 3)
            {
                MessageBox.Show("Nome da Contato inválido");
            }
            else if (txtEndereco.Text == "")
            {
                MessageBox.Show("Endereço inválido");
            }
            else if (cbxCidade.SelectedIndex == -1)
            {
                MessageBox.Show("Cidade inválida");
            }
            else if (txtTelefone.Text == "")
            {
                MessageBox.Show("Telefone inválido");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("E-Mail inválido");
            }

            else
            {
                Contato RegCont = new Contato();

                RegCont.Idcontato = Convert.ToInt32(txtIDContato.Text);
                RegCont.Nomecontato = txtNomeContato.Text;
                RegCont.Endcontato = txtEndereco.Text;
                RegCont.Cidadeidcidade = Convert.ToInt32(cbxCidade.SelectedValue);
                RegCont.Celcontato = txtTelefone.Text;
                RegCont.Emailcontato = txtEmail.Text;
                RegCont.Dtcadastrocontato = dtpDtCadastro.Value;

                if (bInclusao)
                {
                    if (RegCont.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!");

                        txtIDContato.Enabled = false;
                        txtNomeContato.Enabled = false;
                        txtEndereco.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtTelefone.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        txtEmail.Enabled = false;

                        btnIncluir.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCont.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else { MessageBox.Show("Erro ao gravar Contato!"); }
                }
                else
                {
                    if (RegCont.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");
                        dsContato.Tables.Clear(); dsContato.Tables.Add(RegCont.Listar());
                        txtIDContato.Enabled = false;
                        txtNomeContato.Enabled = false;
                        txtEndereco.Enabled = false;
                        cbxCidade.Enabled = false;
                        txtTelefone.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        txtEmail.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnIncluir.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                    }
                    else { MessageBox.Show("Erro ao gravar Contato!"); }
                }
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }

            txtIDContato.Enabled = true;
            txtNomeContato.Enabled = true;
            txtEndereco.Enabled = true;
            cbxCidade.Enabled = true;
            txtTelefone.Enabled = true;
            dtpDtCadastro.Enabled = true;
            txtEmail.Enabled = true;

            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnIncluir.Enabled = false;
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCont = new Contato();

                RegCont.Idcontato = Convert.ToInt32(txtIDContato.Text);
                

                if (RegCont.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    Contato R = new Contato(); dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Contato!");
                }
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnIncluir.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;
            
            txtIDContato.Enabled = false;
            txtNomeContato.Enabled = false;
            txtEndereco.Enabled = false;
            cbxCidade.Enabled = false;
            txtTelefone.Enabled = false;
            dtpDtCadastro.Enabled = false;
            txtEmail.Enabled = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
