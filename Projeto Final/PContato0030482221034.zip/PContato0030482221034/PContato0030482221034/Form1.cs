﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482221034
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Data Source = APOLO; Initial Catalog = LP2; Persist Security Info = True; User ID = BD2221034

            try
            {
                conexao = new SqlConnection("Data Source = APOLO; Initial Catalog = LP2; Persist Security Info = True; User ID = BD2221034; PASSWORD = A12345678a");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void CidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmCidade>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe!");
                Application.OpenForms["FrmCidade"].BringToFront();
            }
            else
            {
                FrmCidade objForm2 = new FrmCidade();
                objForm2.MdiParent = this;
                objForm2.WindowState = FormWindowState.Maximized;
                objForm2.Show();
            }
        }

        private void ContatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmContato>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe!");
                Application.OpenForms["FrmContato"].BringToFront();
            }
            else
            {
                FrmContato objForm2 = new FrmContato();
                objForm2.MdiParent = this;
                objForm2.WindowState = FormWindowState.Maximized;
                objForm2.Show();
            }
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmSobre>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe!");
                Application.OpenForms["FrmSobre"].BringToFront();
            }
            else
            {
                FrmSobre objForm2 = new FrmSobre();
                objForm2.MdiParent = this;
                objForm2.WindowState = FormWindowState.Maximized;
                objForm2.Show();
            }
        }
    }
}
