﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class FrmEx3 : Form
    {
        public FrmEx3()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            string frase, auxiliar = "";

            if (txtFrase.Text.Length > 50)
            {
                MessageBox.Show("Texto tem que ter menos que 50 caracteres");
            }
            else
            {
                frase = txtFrase.Text.Replace(" ", "");
                frase = frase.ToLower();

                char[] vetor = frase.ToCharArray();

                Array.Reverse(vetor);

                foreach (char c in vetor)
                {
                    auxiliar += c;
                }

                if (frase == auxiliar)
                    MessageBox.Show("É palíndromo");
                else
                    MessageBox.Show("Não é palíndromo");
            }
        }
    }
}
