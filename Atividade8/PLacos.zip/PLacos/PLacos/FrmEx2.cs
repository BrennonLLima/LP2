﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class FrmEx2 : Form
    {
        public FrmEx2()
        {
            InitializeComponent();
        }

        private void BtnGerar_Click(object sender, EventArgs e)
        {
            int n;
            float h = 1;

            if (!(int.TryParse(txtN.Text, out n)))
            {
                MessageBox.Show("Favor entrar com valor válido");
                txtN.Focus();
            }
            else if (n == 0)
            {
                MessageBox.Show("Valor não pode ser zero");
            }
            else
            {
                for (var i = 0; i < n; i++)
                {
                    h += 1.0f / (i + 2);
                }
                MessageBox.Show("O número gerado foi H: " + h.ToString());
            }
        }
    }
}
