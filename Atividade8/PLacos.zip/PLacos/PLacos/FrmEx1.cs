﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLacos
{
    public partial class FrmEx1 : Form
    {
        public FrmEx1()
        {
            InitializeComponent();
        }
        private void BtnEspacos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char i in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(i))
                {
                    contador++;
                }
            }
            MessageBox.Show("A quantidade de espaços no texto é: " + contador.ToString("N0"));
        }
        private void BtnR_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char i in rchtxtFrase.Text)
            {
                if (i == 'R' || i == 'r')
                {
                    contador++;
                }
            }
            MessageBox.Show("A quantidade de espaços no texto é: " + contador.ToString("N0"));
        }
        private void BtnPares_Click(object sender, EventArgs e)
        {
            char letraAnterior = '\0';
            int numPares = 0;

            for(var i=0; i<rchtxtFrase.Text.Length;i++)
            {
                if (rchtxtFrase.Text[i] == letraAnterior)
                    numPares += 1;

                letraAnterior = rchtxtFrase.Text[i];
            }
            MessageBox.Show("Número de pares: "+numPares.ToString());
        }
    }
}
