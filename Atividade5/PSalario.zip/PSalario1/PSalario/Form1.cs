﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salarioBruto, salarioLiquido,salarioFamilia, descontoINSS, descontoIRPF;
        public Form1()
        {
            InitializeComponent();
        }
        private void TxtNome_Validated(object sender, EventArgs e)
        {
            if(txtNome.Text.Length < 10)
            {
                MessageBox.Show("Nome deve ter mais de 10 caracteres");
                txtNome.Focus();
            }
        }
        private void TxtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsNumber(e.KeyChar)|| Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
            }
            else if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        private void mskbxSalBruto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        private void nudFilhos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)(13))
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Favor entrar com valor válido");
            }
            else if (salarioBruto <= 0)
            {
                MessageBox.Show("Salário não pode ser menor ou igual a zero");
            }
            else
            {
                //Calculo para INSS
                if (salarioBruto <= 800.47)
                {
                    txtAliqINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtAliqINSS.Text = " 8,65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliqINSS.Text = "9,00%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliqINSS.Text = "11,00%";
                    descontoINSS = 0.11 * salarioBruto;
                }
                else
                {
                    txtAliqINSS.Text = "Teto";
                    descontoINSS = 308.17;
                }
                txtDescINSS.Text = descontoINSS.ToString("N2");

                //Calculo IRPF
                if (salarioBruto < 1257.13)
                {
                    txtAliqIRPF.Text = "Isento";
                    descontoIRPF = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliqIRPF.Text = "15,00%";
                    descontoIRPF = 0.15 * salarioBruto;
                }
                else
                {
                    txtAliqIRPF.Text = "27,50%";
                    descontoIRPF = 0.275 * salarioBruto;
                }
                txtDescIRPF.Text = descontoIRPF.ToString("N2");

                //Calculo Salario Familia
                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = ((int)nudFilhos.Value) * 22.33;
                    txtSalFamilia.Text = salarioFamilia.ToString("N2");
                }
                else if (salarioBruto <= 654.61)
                {
                    salarioFamilia = ((int)nudFilhos.Value) * 15.74;
                    txtSalFamilia.Text = salarioFamilia.ToString("N2");
                }
                else
                {
                    salarioFamilia = 0;
                    txtSalFamilia.Text = salarioFamilia.ToString("N2");
                }

                //Calculo Salario Liquido
                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                txtSalLiquido.Text = salarioLiquido.ToString("N2");

                //Texto
                if (rbtnFeminino.Checked)
                {
                    if (ckbxCasado.Checked)
                    {
                        lblDados.Text = "Os descontos do salário da Sra. "+txtNome.Text+" que é Casada e tem: "+(int)nudFilhos.Value+" filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Os descontos do salário da Sra. " + txtNome.Text + " que é Solteira e tem: " + (int)nudFilhos.Value + " filho(s)";
                    }
                }
                if (rbtnMasculino.Checked)
                {
                    if (ckbxCasado.Checked)
                    {
                        lblDados.Text = "Os descontos do salário da Sr. " + txtNome.Text + " que é Casado e tem: " + (int)nudFilhos.Value + " filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Os descontos do salário da Sr. " + txtNome.Text + " que é Solteiro e tem: " + (int)nudFilhos.Value + " filho(s)";
                    }
                }
            }
        }
    }
}
